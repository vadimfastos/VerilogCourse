var driver__adxl362__fifo_8c =
[
    [ "adxl362_fifo_deinit", "group__adxl362__example__driver.html#gac190746d6818f30ad9fbea7ed8aef120", null ],
    [ "adxl362_fifo_init", "group__adxl362__example__driver.html#gacf3cc07daee8ce8f0b1d8e6e2c548ad1", null ],
    [ "adxl362_fifo_irq_handler", "group__adxl362__example__driver.html#ga502f99345cb9fb9d389135a9e5c738d8", null ]
];