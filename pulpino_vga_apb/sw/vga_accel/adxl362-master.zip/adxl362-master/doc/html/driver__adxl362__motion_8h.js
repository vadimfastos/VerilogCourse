var driver__adxl362__motion_8h =
[
    [ "ADXL362_MOTION_DEFAULT_ACTIVITY_DETECT_TRIGGER", "group__adxl362__example__driver.html#ga99851729f4c232d3d1c7852cf1224394", null ],
    [ "ADXL362_MOTION_DEFAULT_ACTIVITY_THRESHOLD", "group__adxl362__example__driver.html#ga5676a82e5087e09a9e949f873e9c06f6", null ],
    [ "ADXL362_MOTION_DEFAULT_ACTIVITY_TIME", "group__adxl362__example__driver.html#gaab7a3ad76f9558380e9cc9b7dfe8f927", null ],
    [ "ADXL362_MOTION_DEFAULT_BANDWIDTH_ODR", "group__adxl362__example__driver.html#ga1d4e7e9a3cce8bce1b0619a6321385d4", null ],
    [ "ADXL362_MOTION_DEFAULT_DETECT_MODE", "group__adxl362__example__driver.html#ga127accab6c3ce3bd469d63a7a7dd7aa2", null ],
    [ "ADXL362_MOTION_DEFAULT_INACTIVITY_DETECT_TRIGGER", "group__adxl362__example__driver.html#gac14fd509ce9317c81bb3c3f9bd0bc993", null ],
    [ "ADXL362_MOTION_DEFAULT_INACTIVITY_THRESHOLD", "group__adxl362__example__driver.html#ga5b66243d10e0909c442ba3214d811e35", null ],
    [ "ADXL362_MOTION_DEFAULT_INACTIVITY_TIME", "group__adxl362__example__driver.html#gacf909860cd8120bf3ca8035b26d1de68", null ],
    [ "ADXL362_MOTION_DEFAULT_INTERRUPT_PIN_LEVEL", "group__adxl362__example__driver.html#ga2fc85d374aed9fdc5f4bf01a8f16c262", null ],
    [ "ADXL362_MOTION_DEFAULT_NOISE_MODE", "group__adxl362__example__driver.html#ga1bd7a2b14cf3ff5d4e3e3209d904aa11", null ],
    [ "ADXL362_MOTION_DEFAULT_ODR", "group__adxl362__example__driver.html#gaf58f26d38f7f608c69ebeb0f261cb72a", null ],
    [ "ADXL362_MOTION_DEFAULT_RANGE", "group__adxl362__example__driver.html#ga77b926a8674e377cc0f6ee32ea44f6a8", null ],
    [ "adxl362_motion_deinit", "group__adxl362__example__driver.html#gadc254b647d29661e4978d91b646e1911", null ],
    [ "adxl362_motion_init", "group__adxl362__example__driver.html#gacdc8b794356f7d0390d6263f8f1bb31e", null ],
    [ "adxl362_motion_irq_handler", "group__adxl362__example__driver.html#ga5f0b68fbda7f357e3156f9a7dd00c3b9", null ]
];