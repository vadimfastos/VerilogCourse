var driver__adxl362__basic_8c =
[
    [ "adxl362_basic_deinit", "group__adxl362__example__driver.html#ga189bb07bc4815542f3fac25b839f01e4", null ],
    [ "adxl362_basic_init", "group__adxl362__example__driver.html#gae9ba76cba8b18ea39964ccf676fd3f8b", null ],
    [ "adxl362_basic_read", "group__adxl362__example__driver.html#ga278f72813e842d52ddc286ff80b720f5", null ],
    [ "adxl362_basic_read_8msb", "group__adxl362__example__driver.html#gaf78bb72f52b02544a1efbf735d44e5a3", null ],
    [ "adxl362_basic_read_temperature", "group__adxl362__example__driver.html#ga9fa22d36432ddee517105ad0105e97ce", null ]
];