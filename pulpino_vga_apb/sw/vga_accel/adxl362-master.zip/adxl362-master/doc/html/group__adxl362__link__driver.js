var group__adxl362__link__driver =
[
    [ "DRIVER_ADXL362_LINK_DEBUG_PRINT", "group__adxl362__link__driver.html#gaab829ed3616185587b763337707013e0", null ],
    [ "DRIVER_ADXL362_LINK_DELAY_MS", "group__adxl362__link__driver.html#ga9205384e6eb011f5c35773fadc8c3787", null ],
    [ "DRIVER_ADXL362_LINK_INIT", "group__adxl362__link__driver.html#ga7fa4a90e5b18ce98448756d4a5fed4a0", null ],
    [ "DRIVER_ADXL362_LINK_RECEIVE_CALLBACK", "group__adxl362__link__driver.html#gad5bfff2a939d236beb12b89117b6e420", null ],
    [ "DRIVER_ADXL362_LINK_SPI_DEINIT", "group__adxl362__link__driver.html#gab07004732ea9cb400b50489aae045c33", null ],
    [ "DRIVER_ADXL362_LINK_SPI_INIT", "group__adxl362__link__driver.html#ga6ecd657324ba4925d4dbf578bdca75fd", null ],
    [ "DRIVER_ADXL362_LINK_SPI_READ", "group__adxl362__link__driver.html#ga79f2e4dc1e9b127ef49df76fabaa023e", null ],
    [ "DRIVER_ADXL362_LINK_SPI_READ_ADDRESS16", "group__adxl362__link__driver.html#ga6178a77fecf1b9dd1e945b773257f2bb", null ],
    [ "DRIVER_ADXL362_LINK_SPI_WRITE_ADDRESS16", "group__adxl362__link__driver.html#ga75f8c23a8f9f66b10fff730d13c16737", null ]
];