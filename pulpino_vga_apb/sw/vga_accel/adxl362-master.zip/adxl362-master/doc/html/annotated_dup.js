var annotated_dup =
[
    [ "adxl362_frame_s", "structadxl362__frame__s.html", "structadxl362__frame__s" ],
    [ "adxl362_handle_s", "structadxl362__handle__s.html", "structadxl362__handle__s" ],
    [ "adxl362_info_s", "structadxl362__info__s.html", "structadxl362__info__s" ]
];