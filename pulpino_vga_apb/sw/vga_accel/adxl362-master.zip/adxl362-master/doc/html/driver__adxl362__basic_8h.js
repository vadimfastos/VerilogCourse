var driver__adxl362__basic_8h =
[
    [ "ADXL362_BASIC_DEFAULT_BANDWIDTH_ODR", "group__adxl362__example__driver.html#ga442e25c211ba1c9a67c4c63c321b40dc", null ],
    [ "ADXL362_BASIC_DEFAULT_NOISE_MODE", "group__adxl362__example__driver.html#gad981971163783070865bc8f93304c714", null ],
    [ "ADXL362_BASIC_DEFAULT_ODR", "group__adxl362__example__driver.html#ga8e1526e1c75a6e273808cf07a83e772e", null ],
    [ "ADXL362_BASIC_DEFAULT_RANGE", "group__adxl362__example__driver.html#ga4a638efd27d14e5e9bb90b0dad3bb4e0", null ],
    [ "adxl362_basic_deinit", "group__adxl362__example__driver.html#ga189bb07bc4815542f3fac25b839f01e4", null ],
    [ "adxl362_basic_init", "group__adxl362__example__driver.html#gae9ba76cba8b18ea39964ccf676fd3f8b", null ],
    [ "adxl362_basic_read", "group__adxl362__example__driver.html#ga278f72813e842d52ddc286ff80b720f5", null ],
    [ "adxl362_basic_read_8msb", "group__adxl362__example__driver.html#gaf78bb72f52b02544a1efbf735d44e5a3", null ],
    [ "adxl362_basic_read_temperature", "group__adxl362__example__driver.html#ga9fa22d36432ddee517105ad0105e97ce", null ]
];