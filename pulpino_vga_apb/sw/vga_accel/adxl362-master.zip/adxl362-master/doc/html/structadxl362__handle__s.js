var structadxl362__handle__s =
[
    [ "buf", "structadxl362__handle__s.html#a4dc295e16142fe60de6ddf9e875cec89", null ],
    [ "debug_print", "structadxl362__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b", null ],
    [ "delay_ms", "structadxl362__handle__s.html#a406c9433252b7366de417b7a60915c81", null ],
    [ "inited", "structadxl362__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f", null ],
    [ "receive_callback", "structadxl362__handle__s.html#a4a9a1af4e28aea769f6d9f02a02e07c3", null ],
    [ "spi_deinit", "structadxl362__handle__s.html#a9adb2481330acacfd7f6a04ce3310fab", null ],
    [ "spi_init", "structadxl362__handle__s.html#a30df505f4bd8bc8754fc0a36cfbe46d6", null ],
    [ "spi_read", "structadxl362__handle__s.html#af600630b6e1f0f5b2be9eba18e46f92d", null ],
    [ "spi_read_address16", "structadxl362__handle__s.html#a8662a3c5475cfc59e63e61b0a21fb28d", null ],
    [ "spi_write_address16", "structadxl362__handle__s.html#a85c6e3eb7be81e85827de6362d5363a7", null ]
];