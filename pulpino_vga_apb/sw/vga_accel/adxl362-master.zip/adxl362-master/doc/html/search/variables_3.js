var searchData=
[
  ['inited_419',['inited',['../structadxl362__handle__s.html#a19bedf28d2b9748f6a62d9ae93f4e68f',1,'adxl362_handle_s']]],
  ['interface_420',['interface',['../structadxl362__info__s.html#aebaa6c28dd4f2c3dc27566fcb910fd28',1,'adxl362_info_s']]]
];
