var searchData=
[
  ['adxl362_5fframe_5ft_435',['adxl362_frame_t',['../group__adxl362__basic__driver.html#ga52be7a56e66b736c86218afca83cfdfd',1,'driver_adxl362.h']]],
  ['adxl362_5fhandle_5ft_436',['adxl362_handle_t',['../group__adxl362__basic__driver.html#ga58158ef74e434ac781e01a7cf3f09fac',1,'driver_adxl362.h']]],
  ['adxl362_5finfo_5ft_437',['adxl362_info_t',['../group__adxl362__basic__driver.html#ga3713e7351fdac21d3ebbcbf6cbac96ef',1,'driver_adxl362.h']]]
];
