var searchData=
[
  ['supply_5fvoltage_5fmax_537',['SUPPLY_VOLTAGE_MAX',['../driver__adxl362_8c.html#a68eba8b601afe11f1b871d944976c035',1,'driver_adxl362.c']]],
  ['supply_5fvoltage_5fmin_538',['SUPPLY_VOLTAGE_MIN',['../driver__adxl362_8c.html#aac8d8cbd899667d609787ef4cf37054d',1,'driver_adxl362.c']]]
];
