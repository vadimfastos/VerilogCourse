var searchData=
[
  ['buf_232',['buf',['../structadxl362__handle__s.html#a4dc295e16142fe60de6ddf9e875cec89',1,'adxl362_handle_s']]]
];
