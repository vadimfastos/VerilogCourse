var searchData=
[
  ['manufacturer_5fname_535',['MANUFACTURER_NAME',['../driver__adxl362_8c.html#aaa2b8f5b105c3019df0cb346f472e803',1,'driver_adxl362.c']]],
  ['max_5fcurrent_536',['MAX_CURRENT',['../driver__adxl362_8c.html#a2989837a37d6d63b59c6dd541b785435',1,'driver_adxl362.c']]]
];
