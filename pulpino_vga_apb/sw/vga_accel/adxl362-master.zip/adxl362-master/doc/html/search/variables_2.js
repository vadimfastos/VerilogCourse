var searchData=
[
  ['data_415',['data',['../structadxl362__frame__s.html#a173b91873a3fc4f50a95416a6204d963',1,'adxl362_frame_s']]],
  ['debug_5fprint_416',['debug_print',['../structadxl362__handle__s.html#a769d5b3a6c14790a0e126e8fe70b384b',1,'adxl362_handle_s']]],
  ['delay_5fms_417',['delay_ms',['../structadxl362__handle__s.html#a406c9433252b7366de417b7a60915c81',1,'adxl362_handle_s']]],
  ['driver_5fversion_418',['driver_version',['../structadxl362__info__s.html#a41b0bd442708b70d252c50b92c75265a',1,'adxl362_info_s']]]
];
