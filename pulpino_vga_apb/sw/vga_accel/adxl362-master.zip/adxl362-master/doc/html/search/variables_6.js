var searchData=
[
  ['spi_5fdeinit_425',['spi_deinit',['../structadxl362__handle__s.html#a9adb2481330acacfd7f6a04ce3310fab',1,'adxl362_handle_s']]],
  ['spi_5finit_426',['spi_init',['../structadxl362__handle__s.html#a30df505f4bd8bc8754fc0a36cfbe46d6',1,'adxl362_handle_s']]],
  ['spi_5fread_427',['spi_read',['../structadxl362__handle__s.html#af600630b6e1f0f5b2be9eba18e46f92d',1,'adxl362_handle_s']]],
  ['spi_5fread_5faddress16_428',['spi_read_address16',['../structadxl362__handle__s.html#a8662a3c5475cfc59e63e61b0a21fb28d',1,'adxl362_handle_s']]],
  ['spi_5fwrite_5faddress16_429',['spi_write_address16',['../structadxl362__handle__s.html#a85c6e3eb7be81e85827de6362d5363a7',1,'adxl362_handle_s']]],
  ['supply_5fvoltage_5fmax_5fv_430',['supply_voltage_max_v',['../structadxl362__info__s.html#a3d2b12bcac7a85ea8646bff9debe8660',1,'adxl362_info_s']]],
  ['supply_5fvoltage_5fmin_5fv_431',['supply_voltage_min_v',['../structadxl362__info__s.html#ad8bde6ddadaf43d951e62f3befb9d35a',1,'adxl362_info_s']]]
];
