var searchData=
[
  ['raw_423',['raw',['../structadxl362__frame__s.html#a0fa73e362a2e5c784d67168ff308225d',1,'adxl362_frame_s']]],
  ['receive_5fcallback_424',['receive_callback',['../structadxl362__handle__s.html#a4a9a1af4e28aea769f6d9f02a02e07c3',1,'adxl362_handle_s']]]
];
