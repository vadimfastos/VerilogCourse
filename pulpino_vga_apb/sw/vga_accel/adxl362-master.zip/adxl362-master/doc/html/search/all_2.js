var searchData=
[
  ['chip_5fname_233',['chip_name',['../structadxl362__info__s.html#af890958c72bd715cc6454a10dc846ae6',1,'adxl362_info_s']]],
  ['chip_5fname_234',['CHIP_NAME',['../driver__adxl362_8c.html#adc9da0a24824ca1239b593f6459b3954',1,'driver_adxl362.c']]]
];
