var group__adxl362__interface__driver =
[
    [ "adxl362_interface_debug_print", "group__adxl362__interface__driver.html#ga5283f1a5c7e10c84d63f7dc39ae0638b", null ],
    [ "adxl362_interface_delay_ms", "group__adxl362__interface__driver.html#ga29e7b7e01bd947f1b4ce978dde67abcf", null ],
    [ "adxl362_interface_receive_callback", "group__adxl362__interface__driver.html#ga6b43b9bac0b18dccb0fd0e07c3df61e6", null ],
    [ "adxl362_interface_spi_deinit", "group__adxl362__interface__driver.html#ga262246f67f1493797eb53cce56bce778", null ],
    [ "adxl362_interface_spi_init", "group__adxl362__interface__driver.html#ga27d300b48903bd4c91c3ae687e7b2a8b", null ],
    [ "adxl362_interface_spi_read", "group__adxl362__interface__driver.html#ga20cdc94dfe4d6359a235d8b97b75509a", null ],
    [ "adxl362_interface_spi_read_address16", "group__adxl362__interface__driver.html#gaa018ac4218e07d4561318215032cb3f1", null ],
    [ "adxl362_interface_spi_write_address16", "group__adxl362__interface__driver.html#ga2e1918bc77d354ac7c4606ef8490765c", null ]
];