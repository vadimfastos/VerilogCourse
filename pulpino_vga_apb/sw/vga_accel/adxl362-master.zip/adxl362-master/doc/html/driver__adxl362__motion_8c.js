var driver__adxl362__motion_8c =
[
    [ "adxl362_motion_deinit", "group__adxl362__example__driver.html#gadc254b647d29661e4978d91b646e1911", null ],
    [ "adxl362_motion_init", "group__adxl362__example__driver.html#gacdc8b794356f7d0390d6263f8f1bb31e", null ],
    [ "adxl362_motion_irq_handler", "group__adxl362__example__driver.html#ga5f0b68fbda7f357e3156f9a7dd00c3b9", null ]
];