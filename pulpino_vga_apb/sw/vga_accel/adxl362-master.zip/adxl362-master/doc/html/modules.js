var modules =
[
    [ "adxl362 driver function", "group__adxl362__driver.html", "group__adxl362__driver" ]
];