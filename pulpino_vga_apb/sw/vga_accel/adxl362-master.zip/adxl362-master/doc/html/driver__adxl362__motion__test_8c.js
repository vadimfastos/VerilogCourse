var driver__adxl362__motion__test_8c =
[
    [ "adxl362_motion_test", "group__adxl362__test__driver.html#ga869ed5a2cbb9f43985ef71874823c9a5", null ],
    [ "adxl362_motion_test_irq_handler", "group__adxl362__test__driver.html#ga1045eb270b86ca4b1ebacb079aaf9223", null ]
];