var group__adxl362__extern__driver =
[
    [ "adxl362_get_fifo", "group__adxl362__extern__driver.html#gaca4a1f4394a917443b77b1d4ee9ddbf0", null ],
    [ "adxl362_get_reg", "group__adxl362__extern__driver.html#ga04428dc9a3a7726018789bc1cfcb05a0", null ],
    [ "adxl362_set_reg", "group__adxl362__extern__driver.html#gadf34f25c43c4953a556e63e127df7d5c", null ]
];