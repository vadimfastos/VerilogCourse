var structadxl362__frame__s =
[
    [ "data", "structadxl362__frame__s.html#a173b91873a3fc4f50a95416a6204d963", null ],
    [ "raw", "structadxl362__frame__s.html#a0fa73e362a2e5c784d67168ff308225d", null ],
    [ "type", "structadxl362__frame__s.html#a5b60693b053b24f51f409dae40256edc", null ]
];